import React from 'react'

const Catagory = () => {
  return (
    <div>Catagory</div>
  )
}

export default Catagory