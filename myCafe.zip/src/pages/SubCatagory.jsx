import React from 'react'

const SubCatagory = () => {
  return (
    <div>SubCatagory</div>
  )
}

export default SubCatagory