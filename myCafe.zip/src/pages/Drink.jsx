import React from 'react'

const Drink = () => {
  return (
    <div>Drink</div>
  )
}

export default Drink